import { AlgorandClient, Config } from '@algorandfoundation/algokit-utils';
import { MachineContractClient, MachineContractFactory } from '../client/client';
import algosdk, { OnApplicationComplete } from 'algosdk';
import { AlgoAmount } from '@algorandfoundation/algokit-utils/types/amount';

describe('MachineContract Deployment', () => {
  let algorand: AlgorandClient;
  let deployer: algosdk.Account;

  beforeAll(async () => {
    // Set up Algorand client for testnet
    const secretKey = Buffer.from("H74d2kNSqOuxd36+OA03Gy9PLlQ2au6pzlzy9Are1742o/gKgRhqmEePN26LFuAfd2wbXOjFuxtFBSNTHE4lRA==", 'base64')
  const mnemonics  = algosdk.secretKeyToMnemonic(secretKey)
  const deployers  = algosdk.mnemonicToSecretKey(mnemonics)
console.log(mnemonics)
    algorand = AlgorandClient.testNet();

    // Create account from mnemonic
    const mnemonic = "announce feed swing base certain rib rose phrase crouch rotate voyage enroll same sort flush emotion pulp airport notice inject pelican zero blossom about honey";
    deployer = algosdk.mnemonicToSecretKey(mnemonic);

    // Fund account if needed (testnet)
    try {
      const accountInfo = await algorand.account.getInformation(deployer.addr);
      if (accountInfo.balance.microAlgo < 1000000) { // Less than 1 ALGO
        console.log('Account needs funding on testnet');
      }
    } catch (error) {
      console.log('Account not found, may need funding');
    }
  });

  it('should deploy the MachineContract', async () => {
    // Create the typed app factory
    const signer = algosdk.makeBasicAccountTransactionSigner(deployer)

    const appFactory = new MachineContractFactory({
      defaultSender: deployer.addr,
      defaultSigner: signer,
      algorand,
    })

    
    // Deploy the contract with required parameters
    const { appClient } = await appFactory.send.create.createApplication({
      args: {
        ownerAddress: deployer.addr.toString(),
        fixedPricing: AlgoAmount.MicroAlgos(1).microAlgo, // 1 ALGO in microAlgos
      },
      sender: deployer.addr,
      signer: signer,
      onComplete: OnApplicationComplete.NoOpOC,

    });

    // Verify deployment
    expect(appClient.appId).toBeDefined();
    expect(appClient.appId).toBeGreaterThan(0);
    console.log('Deployed MachineContract App ID:', appClient.appId);
  });

  // it('should interact with deployed contract', async () => {
  //   // Deploy first
  //   const factory = algorand.client.getTypedAppFactory(MachineContractClient, {
  //     creatorAddress: deployer.addr,
  //     defaultSender: deployer.addr,
  //   });

  //   const { appClient } = await factory.send.create.createApplication({
  //     args: {
  //       ownerAddress: deployer.addr,
  //       fixedPricing: 500000n // 0.5 ALGO
  //     },
  //     sender: deployer,
  //   });

  //   // Test price change
  //   await appClient.send.changePrice({
  //     args: { pricing: 750000n }, // 0.75 ALGO
  //     sender: deployer,
  //   });

  //   console.log('Successfully changed price on App ID:', appClient.appId);
  //   expect(appClient.appId).toBeDefined();
  // });
});